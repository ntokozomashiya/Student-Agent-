import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EmergencyControlsWidget extends StatefulWidget {
  final Function(String) onCommandExecuted;

  const EmergencyControlsWidget({
    Key? key,
    required this.onCommandExecuted,
  }) : super(key: key);

  @override
  State<EmergencyControlsWidget> createState() =>
      _EmergencyControlsWidgetState();
}

class _EmergencyControlsWidgetState extends State<EmergencyControlsWidget> {
  bool _isLostModeEnabled = false;

  void _showEmergencyUnlockDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'warning',
                color: AppTheme.warningColor,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                'Emergency Unlock',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'This will immediately unlock the device and disable all restrictions temporarily.',
                style: AppTheme.lightTheme.textTheme.bodyMedium,
              ),
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.warningColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: AppTheme.warningColor.withValues(alpha: 0.3),
                  ),
                ),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'info',
                      color: AppTheme.warningColor,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        'Use only in genuine emergency situations. All actions are logged.',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.warningColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                widget.onCommandExecuted('Emergency Unlock');
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'check_circle',
                          color: Colors.white,
                          size: 20,
                        ),
                        SizedBox(width: 2.w),
                        Text('Emergency unlock activated'),
                      ],
                    ),
                    backgroundColor: AppTheme.warningColor,
                    duration: const Duration(seconds: 4),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.warningColor,
                foregroundColor: Colors.white,
              ),
              child: Text('Emergency Unlock'),
            ),
          ],
        );
      },
    );
  }

  void _showLostModeDialog() {
    final TextEditingController messageController = TextEditingController();
    final TextEditingController contactController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: _isLostModeEnabled ? 'location_off' : 'my_location',
                color: _isLostModeEnabled
                    ? AppTheme.successColor
                    : AppTheme.errorLight,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                _isLostModeEnabled ? 'Disable Lost Mode' : 'Enable Lost Mode',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          content: SizedBox(
            width: 80.w,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (!_isLostModeEnabled) ...[
                  Text(
                    'Lost Mode will lock the device and display a custom message with contact information.',
                    style: AppTheme.lightTheme.textTheme.bodyMedium,
                  ),
                  SizedBox(height: 2.h),
                  TextField(
                    controller: messageController,
                    decoration: InputDecoration(
                      labelText: 'Lost Device Message',
                      hintText: 'This device is lost. Please contact...',
                    ),
                    maxLines: 3,
                  ),
                  SizedBox(height: 2.h),
                  TextField(
                    controller: contactController,
                    decoration: InputDecoration(
                      labelText: 'Contact Information',
                      hintText: 'Phone number or email',
                    ),
                  ),
                ] else ...[
                  Text(
                    'This will disable Lost Mode and restore normal device functionality.',
                    style: AppTheme.lightTheme.textTheme.bodyMedium,
                  ),
                  SizedBox(height: 2.h),
                  Container(
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.successColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: AppTheme.successColor.withValues(alpha: 0.3),
                      ),
                    ),
                    child: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'check_circle',
                          color: AppTheme.successColor,
                          size: 20,
                        ),
                        SizedBox(width: 2.w),
                        Expanded(
                          child: Text(
                            'Lost Mode is currently active',
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme.successColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                messageController.dispose();
                contactController.dispose();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  _isLostModeEnabled = !_isLostModeEnabled;
                });

                if (_isLostModeEnabled) {
                  widget.onCommandExecuted(
                      'Enable Lost Mode: ${messageController.text}');
                } else {
                  widget.onCommandExecuted('Disable Lost Mode');
                }

                messageController.dispose();
                contactController.dispose();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _isLostModeEnabled
                    ? AppTheme.successColor
                    : AppTheme.errorLight,
                foregroundColor: Colors.white,
              ),
              child: Text(_isLostModeEnabled ? 'Disable' : 'Enable'),
            ),
          ],
        );
      },
    );
  }

  void _showFactoryResetDialog() {
    final TextEditingController confirmationController =
        TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'warning',
                    color: AppTheme.errorLight,
                    size: 24,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Factory Reset',
                    style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppTheme.errorLight,
                    ),
                  ),
                ],
              ),
              content: SizedBox(
                width: 80.w,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.all(3.w),
                      decoration: BoxDecoration(
                        color: AppTheme.errorLight.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: AppTheme.errorLight.withValues(alpha: 0.3),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'dangerous',
                                color: AppTheme.errorLight,
                                size: 20,
                              ),
                              SizedBox(width: 2.w),
                              Text(
                                'DANGER: This action cannot be undone',
                                style: AppTheme.lightTheme.textTheme.titleSmall
                                    ?.copyWith(
                                  color: AppTheme.errorLight,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 1.h),
                          Text(
                            'Factory reset will permanently erase all data, settings, and applications on this device.',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.errorLight,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      'Type "FACTORY RESET" to confirm:',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    TextField(
                      controller: confirmationController,
                      decoration: InputDecoration(
                        hintText: 'FACTORY RESET',
                        border: OutlineInputBorder(
                          borderSide: BorderSide(color: AppTheme.errorLight),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: AppTheme.errorLight, width: 2),
                        ),
                      ),
                      onChanged: (value) {
                        setDialogState(() {});
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    confirmationController.dispose();
                  },
                  child: Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: confirmationController.text == 'FACTORY RESET'
                      ? () {
                          Navigator.of(context).pop();
                          widget.onCommandExecuted('Factory Reset');
                          confirmationController.dispose();

                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Row(
                                children: [
                                  CustomIconWidget(
                                    iconName: 'warning',
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                  SizedBox(width: 2.w),
                                  Text('Factory reset initiated'),
                                ],
                              ),
                              backgroundColor: AppTheme.errorLight,
                              duration: const Duration(seconds: 5),
                            ),
                          );
                        }
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.errorLight,
                    foregroundColor: Colors.white,
                  ),
                  child: Text('Factory Reset'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildEmergencyButton({
    required String title,
    required String iconName,
    required VoidCallback onPressed,
    required Color color,
    String? subtitle,
  }) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(bottom: 2.h),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: color.withValues(alpha: 0.1),
          foregroundColor: color,
          elevation: 2,
          shadowColor: AppTheme.shadowLight,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: color.withValues(alpha: 0.3),
              width: 1.5,
            ),
          ),
          padding: EdgeInsets.all(4.w),
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: iconName,
                color: color,
                size: 24,
              ),
            ),
            SizedBox(width: 4.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: color,
                    ),
                  ),
                  if (subtitle != null) ...[
                    SizedBox(height: 0.5.h),
                    Text(
                      subtitle,
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: color.withValues(alpha: 0.8),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            CustomIconWidget(
              iconName: 'arrow_forward_ios',
              color: color,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.errorLight.withValues(alpha: 0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.errorLight.withValues(alpha: 0.1),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: AppTheme.errorLight.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: 'emergency',
                  color: AppTheme.errorLight,
                  size: 24,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Emergency Controls',
                      style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.errorLight,
                      ),
                    ),
                    Text(
                      'Use with extreme caution',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.errorLight.withValues(alpha: 0.8),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildEmergencyButton(
            title: 'Emergency Unlock',
            subtitle: 'Immediately unlock device and disable restrictions',
            iconName: 'lock_open',
            color: AppTheme.warningColor,
            onPressed: _showEmergencyUnlockDialog,
          ),
          _buildEmergencyButton(
            title:
                _isLostModeEnabled ? 'Disable Lost Mode' : 'Enable Lost Mode',
            subtitle: _isLostModeEnabled
                ? 'Currently active - click to disable'
                : 'Lock device and display recovery message',
            iconName: _isLostModeEnabled ? 'location_off' : 'my_location',
            color: _isLostModeEnabled
                ? AppTheme.successColor
                : AppTheme.errorLight,
            onPressed: _showLostModeDialog,
          ),
          _buildEmergencyButton(
            title: 'Factory Reset',
            subtitle: 'Permanently erase all data - cannot be undone',
            iconName: 'settings_backup_restore',
            color: AppTheme.errorLight,
            onPressed: _showFactoryResetDialog,
          ),
        ],
      ),
    );
  }
}
