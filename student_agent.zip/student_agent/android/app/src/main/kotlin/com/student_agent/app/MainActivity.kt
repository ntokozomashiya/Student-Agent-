package com.student_agent.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
